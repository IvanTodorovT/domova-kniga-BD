<?php
const USER = 'root';
const PASS= 'rootroot';

$username = isset ($_POST['username']) ? $_POST['username'] : ""; 
$password = isset ($_POST['password']) ? $_POST['password'] : "";

$arr = [];

if ($name == USER && $password == PASS){
	$arr['status'] = "echo";
	
}

else {
	
	$arr['status'] = "no echo";
}

echo json_encode($arr);