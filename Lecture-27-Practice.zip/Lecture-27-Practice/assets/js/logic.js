/**
 * 
 */

$(function() {
	
	$('#loginBtn').on('click', function() {
		
		var username = $('#username').val();
		var password = $('#password').val();
		
		$.post('index.php', {
			username : username,
			password : password
		}, function(data) {

		})
	});
})


$('#form').submit(function() {
     

     if($('#username').val().length == 0 || $('#password').val().length == 0){
    	 alert("Not submitting");
    	 return false;
     }
    else {
    	 document.form.submit();
    	 alert("Pass");
    	 return true;
}
     
    
});